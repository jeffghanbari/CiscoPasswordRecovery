﻿# Cisco Console Recovery - Windows PowerShell 5.1 / .NET SerialPort
# Intended only for equipment you administer. No external modules required.
param([int]$BaudRate = 9600)
$ErrorActionPreference = 'Stop'
$Host.UI.RawUI.WindowTitle = 'Cisco Console Recovery'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
$script:buffer = ''
$script:transcript = New-Object System.Text.StringBuilder
$script:device = 'UnknownCisco'
$script:phase = 'WaitingForBootloader'
$script:family = 'Unknown'
$script:success = $false
$script:lastText = ''
$script:serial = $null
$script:log = Join-Path $root ("Cisco_Unknown_" + $stamp + '.log')
$script:started = Get-Date
$script:step = 0
$script:category = ''
$script:legacyBackup = 'flash:config.text.recovery_backup'
$script:initialOutput = ''
# Pagination state is shared across all Receive() invocations, because a marker
# such as "-- MORE --" may be split across separate SerialPort read chunks.
$script:pagerTail = ''
$script:pagerChars = 0L
$script:pagerLastHandledEnd = -1L
$script:pagerResponses = 0
$script:pagerMaximum = 1000


function Log([string]$text,[string]$level='INFO') {
  $line = '[{0}] [{1}] {2}' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'),$level,$text
  Write-Host $line -ForegroundColor $(if($level -eq 'ERROR'){'Red'}elseif($level -eq 'WARN'){'Yellow'}else{'Gray'})
  [void]$script:transcript.AppendLine($line)
  Add-Content -LiteralPath $script:log -Value $line -Encoding UTF8
}
function Receive([int]$milliseconds=900) {
  $until = (Get-Date).AddMilliseconds($milliseconds)
  $s = ''
  while((Get-Date) -lt $until) {
    if($script:serial.BytesToRead -gt 0) {
      $chunk = $script:serial.ReadExisting()
      # Match NEW pager markers spanning serial chunks, and answer with a single
      # SPACE (not WriteLine/CR). Absolute character positions prevent responding
      # repeatedly to an old marker still present in a rolling buffer.
      $combined = $script:pagerTail + $chunk
      $basePos = $script:pagerChars - $script:pagerTail.Length
      $pagerPattern = '(?i)--\s*MORE\s*--|<---\s*More\s*--->'
      foreach($m in [regex]::Matches($combined,$pagerPattern)) {
        $endPos = [long]($basePos + $m.Index + $m.Length)
        if($endPos -gt $script:pagerLastHandledEnd) {
          $script:pagerLastHandledEnd = $endPos
          $script:pagerResponses++
          if($script:pagerResponses -gt $script:pagerMaximum) {
            throw 'Too many pagination prompts. Stopped to avoid an endless loop.'
          }
          $script:serial.Write(' ')
          # Do not log per-page responses: command output can span many pages.
        }
      }
      $script:pagerChars += $chunk.Length
      if($combined.Length -gt 64) {
        $script:pagerTail = $combined.Substring($combined.Length - 64)
      } else {
        $script:pagerTail = $combined
      }
      $s += $chunk
      $script:buffer += $chunk
      if($script:buffer.Length -gt 120000) {$script:buffer=$script:buffer.Substring($script:buffer.Length-120000)}
      # Keep full console output, but redact secrets in the command echo.
      $safe = $chunk -replace '123456@zxc','[REDACTED]'
      Add-Content -LiteralPath $script:log -Value $safe -NoNewline -Encoding UTF8
      Write-Host $safe -NoNewline
    }
    Start-Sleep -Milliseconds 80
  }
  $script:lastText = $s
  return $s
}
function Send([string]$cmd,[int]$wait=1000,[bool]$secret=$false) {
  Log ("TX: " + $(if($secret){'[REDACTED COMMAND]'}else{$cmd}))
  $script:serial.Write($cmd + "`r")
  return (Receive $wait)
}
# Wait for a fresh bootloader prompt after a command has finished; never assume fixed delays.
function WaitSwitchPrompt([int]$timeoutSeconds=120,[string]$initial='') {
  $collected = $initial
  $deadline = (Get-Date).AddSeconds($timeoutSeconds)
  while((Get-Date) -lt $deadline) {
    # Only accept a switch: prompt at the END of the current command's output.
    # The old prompt printed before the command must not be mistaken for completion.
    if($collected -match '(?s)(?:^|[\r\n])\s*switch:\s*$') { return $collected }
    $collected += Receive 650
    if($collected.Length -gt 150000) { $collected=$collected.Substring($collected.Length-150000) }
  }
  throw "Timed out waiting for switch: prompt after $timeoutSeconds seconds; no further Flash changes made."
}
function SwitchCommand([string]$command,[int]$timeoutSeconds=90) {
  $script:buffer=''
  Log "TX: $command"
  $script:serial.Write($command + "`r")
  $answer=WaitSwitchPrompt $timeoutSeconds
  # Check complete output, not merely the first chunk.
  if(Failed $answer -or $answer -match '(?im)(?:^|\n)\s*(?:error:|unknown command|cannot|usage:)') {
    throw "Bootloader command rejected: $command"
  }
  return $answer
}
# Recognize a file ONLY in a full dir flash: entry (index, flags, byte size,
# optional date/time columns, filename). Classic C2960 shows <date> between size
# and filename. Do not count echoed commands or other filenames as matches.
function FlashFileExists([string]$listing,[string]$name) {
  $escaped=[regex]::Escape($name)
  foreach($line in ($listing -split "`r?`n")) {
    $pattern='^\s*\d+\s+[-d][rwx-]{3,10}\s+\d+\s+(?:\S+\s+){0,5}' + $escaped + '\s*$'
    if($line -match $pattern) { return $true }
  }
  return $false
}
# IOS can print unsolicited syslog/RSA-key messages after an otherwise valid prompt.
# Check complete lines, not just the final bytes of the capture.
function HasPrivAnywhere([string]$s) {
  return ($s -match '(?im)(?:^|[\r\n])\s*[A-Za-z0-9_.()/:-]+#(?=\s*(?:[\r\n]|$)|[^\r\n]*%[A-Z][A-Z0-9_-]*-\d+-)')
}
function WaitPrivPrompt([int]$timeoutSeconds=90,[string]$initial='') {
  $capture=$initial
  $deadline=(Get-Date).AddSeconds($timeoutSeconds)
  $nextProbe=(Get-Date).AddSeconds(3)
  while((Get-Date) -lt $deadline) {
    if(HasPrivAnywhere $capture) {
      # A standalone prompt is sufficient even if a log message followed it.
      return $capture
    }
    $capture += Receive 650
    if($capture -match '(?im)(?:^|[\r\n])\s*Password:\s*$') { throw 'Enable requested a password; no credential guessing attempted.' }
    if($capture.Length -gt 160000) {$capture=$capture.Substring($capture.Length-160000)}
    if((Get-Date) -ge $nextProbe) {
      # Enter is safe and refreshes the prompt; do not resend any credential command.
      $script:serial.Write("`r")
      $nextProbe=(Get-Date).AddSeconds(4)
    }
  }
  throw "Timed out waiting for privileged EXEC prompt ($timeoutSeconds seconds)."
}
# Track all serial chunks across the complete save transaction. For IOS copy run->start,
# success is normally [OK], not "bytes copied" (which applies to other copy operations).
function WaitCopyResult([int]$timeoutSeconds=120,[string]$initial='') {
  $capture=$initial
  $deadline=(Get-Date).AddSeconds($timeoutSeconds)
  $confirmationSent=$false
  $sawOK=$false
  $probeAt=(Get-Date).AddSeconds(5)
  while((Get-Date) -lt $deadline) {
    if(-not $confirmationSent -and $capture -match '(?im)Destination filename\s*\[startup-config\]\?') {
      $script:serial.Write("`r")
      $confirmationSent=$true
      Log 'Accepted default startup-config destination'
    }
    if($capture -match '(?im)%\s*(?:Error|Failed)|error writing|copy aborted|\[failed\]') {
      throw 'Configuration save returned an explicit error.'
    }
    # [OK] can appear after asynchronous PKI/syslog lines and need not be the final line.
    if($capture -match '(?im)^\s*\[OK\]\s*$') { $sawOK=$true }
    if($sawOK) {
      Log 'Cisco IOS reported [OK] for configuration save.'
      return $capture
    }
    $capture += Receive 650
    if($capture.Length -gt 180000) {$capture=$capture.Substring($capture.Length-180000)}
    # Some platforms do not redraw their prompt automatically. Do not send Enter
    # while a destination-filename confirmation is awaiting a reply.
    if($confirmationSent -and (Get-Date) -ge $probeAt -and $capture -match '(?im)Building configuration') {
      $probeAt=(Get-Date).AddSeconds(8)
    }
  }
  throw 'Configuration save did not return [OK] within timeout; inspect startup-config before reload.'
}
# Read a full IOS command response and wait for a fresh EXEC prompt without
# accidentally accepting the prompt preceding the echoed command.
function ExecUntilPriv([string]$command,[int]$timeoutSeconds=45) {
  $script:buffer=''
  Log "TX: $command"
  $script:serial.Write($command + "`r")
  $capture=''
  $deadline=(Get-Date).AddSeconds($timeoutSeconds)
  while((Get-Date) -lt $deadline) {
    $capture += Receive 450
    if(Failed $capture) {throw "Command rejected: $command"}
    if($capture -match '(?im)(?:^|[\r\n])\s*[A-Za-z0-9_.()/:-]+#\s*$') {return $capture}
  }
  throw "Timed out waiting for output of $command"
}
function HasRommon([string]$s) { return ($s -match '(?im)(?:^|\r|\n)\s*rommon\s*\d*\s*>\s*$') }
function HasSwitchLoader([string]$s) {return ($s -match '(?im)(?:^|\r|\n)\s*switch\s*:\s*$')}
function HasPriv([string]$s) {return (HasPrivAnywhere $s)}
function HasUser([string]$s) {return ($s -match '(?im)(?:^|\r|\n)\s*[\w()./-]+>\s*$')}
function HasConfig([string]$s) {return ($s -match '(?im)\(config[^)]*\)#\s*$')}
function Failed([string]$s) { return ($s -match '(?im)%\s*(?:Invalid input|Error|Unknown command|Incomplete command|Ambiguous command)|Error opening|not found|permission denied') }
function BreakOnce {
  try {
    $script:serial.BreakState = $true
    Start-Sleep -Milliseconds 350
    $script:serial.BreakState = $false
    Log 'Sent serial BREAK'
  } catch { Log "Serial BREAK failed: $($_.Exception.Message)" 'WARN' }
}
function AwaitPrompt([int]$seconds=240) {
  $until=(Get-Date).AddSeconds($seconds)
  while((Get-Date) -lt $until) {
    $out=Receive 1200
    if($out -match '(?i)initial configuration dialog|would you like to enter the initial configuration dialog|autoinstall') { [void](Send 'no' 1000) }
    if($out -match '(?i)press return to get started|press enter to continue') {[void](Send '' 1000)}
    if($script:buffer -match '(?im)Destination filename\s*\[running-config\]\?\s*$') {[void](Send '' 1000)}
    if(HasPriv $script:buffer) {return 'priv'}
    if(HasUser $script:buffer) {return 'user'}
    if($script:buffer -match '(?im)(?:^|\n)\s*(?:username:|password:)\s*$') {throw 'Authentication prompt encountered; startup config may not have been bypassed.'}
  }
  throw 'Timeout waiting for IOS EXEC prompt.'
}
function Exec([string]$command,[int]$wait=1400,[bool]$secret=$false) {
  $script:buffer=''
  $out=Send $command $wait $secret
  if(Failed $out){throw "Command rejected: $command"}
  return $out
}
try {
  Log 'Cisco Console Recovery v2.8 - requires console connection and physical power-cycle'
  Log 'WARNING: run only on devices you own or administer; this changes administrative credentials.' 'WARN'
  Write-Host "`nJafar Ghanbari Shohani instagram page= ghanbarinetwork" -ForegroundColor Red
  Write-Host "`n======= Select Cisco device category =======" -ForegroundColor Cyan
  Write-Host '1 - Cisco ISR (1800/2800/2900/3900/4000, IOS or IOS-XE)'
  Write-Host '2 - Cisco ASR routers (ASR1000, IOS-XE ROMMON)'
  Write-Host '3 - Legacy Catalyst (2960/3560/3750, classic IOS, MODE button)'
  Write-Host '4 - Catalyst 9000 (9200/9300/9400/9500, IOS-XE, MODE button)'
  Write-Host '5 - Other / unknown: console monitor only (no automatic changes)'
  $choice=Read-Host 'Choose category (1-5)'
  switch($choice) {
    '1' {$script:category='ISR'}
    '2' {$script:category='ASR'}
    '3' {$script:category='LegacyCatalyst'}
    '4' {$script:category='Catalyst9K'}
    '5' {$script:category='MonitorOnly'}
    default {throw 'Invalid device category. Choose 1-5.'}
  }
  Log "Selected category: $($script:category)"
  if($script:category -eq 'LegacyCatalyst') {
    Write-Host "`nLEGACY CATALYST 2960/3560/3750 - PHYSICAL MODE PROCEDURE" -ForegroundColor Yellow
    Write-Host '1. Keep switch POWER OFF and connect the console cable.'
    Write-Host '2. After the serial port opens, PRESS AND HOLD the MODE button.'
    Write-Host '3. While holding MODE, connect switch power.'
    Write-Host '4. Hold until the boot process stops and the switch: prompt appears.'
    Write-Host '5. Release MODE. The script will detect switch: and continue.'
    Write-Host 'NOTE: Some variants have different LED/release timing; trust switch: prompt.'
    Write-Host 'NOTE: This path temporarily renames flash:config.text, then restores its contents.'
    Write-Host 'NOTE: If original and recovery backup both exist, old backup is archived with a timestamp before replacement.'
    Write-Host 'If MODE is not held at power-on, BREAK will NOT stop a legacy Catalyst boot.'
  } elseif($script:category -eq 'Catalyst9K') {
    Write-Host "`nCATALYST 9000 - MODE PROCEDURE" -ForegroundColor Yellow
    Write-Host 'Power OFF the switch; hold MODE while powering ON until the bootloader prompt appears.'
    Write-Host 'Release MODE when switch: is shown. Button timing varies by platform.'
  } elseif($script:category -eq 'MonitorOnly') {
    Write-Host 'Monitor mode: console output will be logged; no recovery commands sent.' -ForegroundColor Yellow
  } else {
    Write-Host 'Power OFF router. Once console is opened, power it ON. Serial BREAK will be sent during early boot.' -ForegroundColor Yellow
  }
  $ports = @([System.IO.Ports.SerialPort]::GetPortNames() | Sort-Object)
  Log ('Available COM ports: ' + $(if($ports.Count){$ports -join ', '}else{'none detected'}))
  $portName=Read-Host 'Enter COM port (example COM3 or 3)'
  if($portName -match '^\d+$') {$portName='COM'+$portName}
  if($portName -notmatch '^COM\d+$') {throw 'Invalid COM port.'}
  $script:serial=New-Object System.IO.Ports.SerialPort($portName,$BaudRate,[System.IO.Ports.Parity]::None,8,[System.IO.Ports.StopBits]::One)
  $script:serial.Handshake=[System.IO.Ports.Handshake]::None
  $script:serial.ReadTimeout=250
  $script:serial.WriteTimeout=2500
  $script:serial.DtrEnable=$false
  $script:serial.RtsEnable=$false
  $script:serial.Encoding=[System.Text.Encoding]::ASCII
  $script:serial.Open()
  Log "Opened $portName at $BaudRate 8N1; power on the Cisco device now."
  $deadline=(Get-Date).AddMinutes(5)
  $lastBreak=(Get-Date).AddSeconds(-10)
  $sawOutput=$false
  while((Get-Date) -lt $deadline) {
    $out=Receive 700
    if($out.Length -gt 0) {$sawOutput=$true}
    if(HasRommon $script:buffer) {$script:family='RouterROMMON';break}
    if(HasSwitchLoader $script:buffer) {$script:family='SwitchLoader';break}
    if($script:buffer -match '(?im)password recovery (?:is )?disabled|password recovery mechanism has been disabled') {throw 'Password recovery disabled on device. Stopping to protect configuration.'}
    if($script:buffer -match '(?im)(?:^|\n)[\w()./-]+[>#]\s*$') {throw 'Device booted into IOS before recovery loader was reached. For legacy Catalyst, hold MODE during power-on and retry.'}
    if($script:category -in @('ISR','ASR') -and ((Get-Date)-$lastBreak).TotalSeconds -gt 2.5 -and $sawOutput) {BreakOnce; $lastBreak=Get-Date}
  }
  if($script:family -eq 'Unknown') {throw 'Unable to reach ROMMON/loader within 5 minutes. If using Catalyst, hold MODE during power-on.'}
  if($script:category -eq 'MonitorOnly') {throw 'Monitor-only option does not execute recovery.'}
  if($script:category -in @('ISR','ASR') -and $script:family -ne 'RouterROMMON') {throw 'Unexpected switch bootloader on router profile. No commands issued.'}
  if($script:category -in @('LegacyCatalyst','Catalyst9K') -and $script:family -ne 'SwitchLoader') {throw 'Unexpected ROMMON on Catalyst profile. No commands issued.'}
  Log "Bootloader detected: $($script:family)"
  if($script:family -eq 'RouterROMMON') {
    # This register command is not universal across Cisco hardware; validate response.
    $script:buffer=''
    $out=Send 'confreg 0x2142' 1800
    if(Failed $out -or $out -match '(?i)usage:\s*confreg|invalid|unsupported') {throw 'ROMMON did not accept confreg 0x2142; unsupported platform, no reset issued.'}
    if(-not (HasRommon $script:buffer)) {throw 'ROMMON prompt not verified after confreg.'}
    Log 'Set config register to 0x2142 (skip startup-config)'
    $script:buffer=''
    [void](Send 'reset' 1500)
  } elseif($script:category -eq 'LegacyCatalyst') {
    # Classic IOS switches use flash:config.text, NOT SWITCH_IGNORE_STARTUP_CFG.
    $init=SwitchCommand 'flash_init' 120
    Log 'flash_init completed and switch: prompt returned.'
    $listing=SwitchCommand 'dir flash:' 90
    # A previous failed run may already have successfully renamed config.text.
    # When both exist, archive old backup first so neither configuration is destroyed.
    $hasOriginal=FlashFileExists $listing 'config.text'
    $hasBackup=FlashFileExists $listing 'config.text.recovery_backup'
    if($hasOriginal -and $hasBackup) {
      # Never destructively overwrite the prior backup: archive it under a unique name
      # first, then replace the fixed recovery_backup name with current config.text.
      $archiveBase='config.text.recovery_previous_' + (Get-Date -Format 'yyyyMMdd_HHmmss')
      $archiveName=$archiveBase
      $counter=1
      while(FlashFileExists $listing $archiveName) {
        $archiveName=$archiveBase + '_' + $counter
        $counter++
      }
      Log "Both config files found. Archiving old recovery backup to flash:$archiveName before replacing it." 'WARN'
      [void](SwitchCommand "rename flash:config.text.recovery_backup flash:$archiveName" 90)
      $listing=SwitchCommand 'dir flash:' 90
      if(-not (FlashFileExists $listing $archiveName) -or (FlashFileExists $listing 'config.text.recovery_backup')) {
        throw "Old backup archive not verified at flash:$archiveName. Stopping without touching config.text."
      }
      Log "Old recovery backup safely preserved as flash:$archiveName"
      # Continue below: config.text is still present and fixed-name backup is absent.
      $hasBackup=$false
    }
    if(-not $hasOriginal -and -not $hasBackup) {
      throw 'Neither config.text nor recovery backup found in completed Flash listing. No Flash changes made.'
    }
    if($hasBackup) {
      Log 'Found preserved config.text.recovery_backup from a prior run; verified it exists. Skipping rename.' 'WARN'
    } else {
      $rename=SwitchCommand 'rename flash:config.text flash:config.text.recovery_backup' 90
      if($rename -match '(?i)overwrite|confirm|are you sure') {throw 'Unexpected rename confirmation. Inspect Flash before continuing.'}
      $listing=SwitchCommand 'dir flash:' 90
      if(-not (FlashFileExists $listing 'config.text.recovery_backup') -or (FlashFileExists $listing 'config.text')) {
        throw 'Rename post-check failed: backup must exist and original must be absent. Check Flash before continuing.'
      }
      Log 'Verified original config has been preserved as flash:config.text.recovery_backup.'
    }
    $script:buffer=''
    [void](Send 'boot' 1700)
  } else {
    # Catalyst 9000 / IOS-XE loader only.
    $script:buffer=''
    $out=Send 'SWITCH_IGNORE_STARTUP_CFG=1' 1200
    if(Failed $out) {
      $script:buffer=''
      $out=Send 'set SWITCH_IGNORE_STARTUP_CFG=1' 1200
      if(Failed $out){throw 'Loader does not support SWITCH_IGNORE_STARTUP_CFG; stopped.'}
    }
    $script:buffer=''
    $vars=Send 'set' 1400
    if($vars -notmatch '(?im)SWITCH_IGNORE_STARTUP_CFG\s*=\s*1') {throw 'Cannot verify bypass variable. Stopped.'}
    Log 'Verified SWITCH_IGNORE_STARTUP_CFG=1'
    $script:buffer=''
    [void](Send 'boot' 1800)
  }
  Log 'Waiting for Cisco IOS / IOS-XE startup (maximum 8 minutes)'
  $script:buffer=''
  $mode=AwaitPrompt 480
  if($mode -eq 'user') {
    $script:buffer=''
    $enableOutput=Send 'enable' 1200
    # StackManager/USB_CONSOLE syslog can be inserted directly after Switch# on 2960S.
    # Collect more serial data, then probe with Enter; do not issue enable again.
    $enableOutput=WaitPrivPrompt 45 $enableOutput
    Log 'Confirmed privileged EXEC after enable (asynchronous syslog tolerated).' 
  }
  Log 'Privileged EXEC reached'
  $v=Exec 'terminal length 0' 800
  $v=Exec 'show version' 1900
  $model=''
  if($v -match '(?im)^\s*[Cc]isco\s+([\w-]+)\s+\(') {$model=$Matches[1]}
  if(-not $model -and $v -match '(?im)^\s*Model [Nn]umber\s*:\s*(\S+)') {$model=$Matches[1]}
  if(-not $model -and $v -match '(?im)^\s*[Cc]isco\s+([\w-]+)\s+processor') {$model=$Matches[1]}
  $hn=Exec 'show running-config | include ^hostname ' 900
  if($hn -match '(?im)^hostname\s+(\S+)') {$script:device=$Matches[1]}
  elseif($model) {$script:device=$model}
  $script:device=$script:device -replace '[^a-zA-Z0-9_.-]','_'
  $newlog=Join-Path $root ($script:device + '_' + $stamp + '_Recovery.log')
  Move-Item -LiteralPath $script:log -Destination $newlog -Force
  $script:log=$newlog
  Log "Device: $($script:device); model: $model"
  # Merge original settings before modifying credentials.
  $script:buffer=''
  if($script:category -eq 'LegacyCatalyst') {
    $r=Send 'copy flash:config.text.recovery_backup running-config' 2000
  } else {
    $r=Send 'copy startup-config running-config' 1800
  }
  if($r -match '(?im)Destination filename\s*\[running-config\]\?') {$r += Send '' 2500}
  if(Failed $r -or $r -match '(?i)source file not found|no such file|not present') {throw 'Could not merge original configuration. Stopping.'}
  if(-not (HasPriv $script:buffer)) {
    $postCopy=WaitPrivPrompt 45 $script:buffer
    if(-not (HasPrivAnywhere $postCopy)) {throw 'No privileged prompt after copying configuration.'}
  }
  Log 'Merged startup-config into running-config'
  $script:buffer=''
  $r=Send 'configure terminal' 1000
  if(-not (HasConfig $script:buffer)) {throw 'Unable to enter global configuration mode.'}
  $r=Exec 'username admin privilege 15 secret 123456@zxc' 1000 $true
  $r=Exec 'enable secret 123456@zxc' 1000 $true
  if($script:family -eq 'RouterROMMON') {
    $r=Exec 'config-register 0x2102' 1100
    Log 'Restored normal config register 0x2102'
  } elseif($script:category -eq 'Catalyst9K') {
    $r=Exec 'no system ignore startupconfig switch all' 1100
    Log 'Disabled ignore-startup-config'
  }
  $script:buffer=''
  $r=Send 'end' 1000
  $r=WaitPrivPrompt 90 $r
  Log 'Verified privileged EXEC after end (including asynchronous IOS messages).'
  $script:buffer=''
  Log 'TX: copy running-config startup-config'
  $script:serial.Write("copy running-config startup-config`r")
  $r=WaitCopyResult 120
  Log 'Save command returned [OK]; checking persistent startup configuration next.'
  if($script:category -eq 'LegacyCatalyst') {
    $check=Exec 'dir flash:' 1200
    if(-not (FlashFileExists $check 'config.text')) {throw 'Saved flash:config.text not verified; manual review required.'}
    Log 'Original pre-recovery config retained at flash:config.text.recovery_backup'
  }
  $verify=ExecUntilPriv 'show startup-config | include ^username admin|^enable secret' 60
  if($verify -notmatch '(?im)^username\s+admin\b' -or $verify -notmatch '(?im)^enable secret\b') {throw 'Saved startup-config does not contain expected admin and enable secret entries.'}
  Log 'Verified admin and enable secret entries in startup-config.'
  $verify=Exec 'show running-config | include ^username admin|^enable secret' 1000
  if($verify -notmatch '(?im)^username\s+admin\b' -or $verify -notmatch '(?im)^enable secret\b') {throw 'Could not verify admin account and enable secret in running-config.'}
  $verify=Exec 'show version | include Configuration register|register is' 900
  if($script:family -eq 'RouterROMMON' -and $verify -notmatch '(?i)0x2102') {Log 'Unable to confirm effective 0x2102 register from show version. Check manually before reload.' 'WARN'}
  if($script:category -eq 'Catalyst9K') {
    $rv=Exec 'show romvar | include SWITCH_IGNORE_STARTUP_CFG' 900
    if($rv -match '(?i)SWITCH_IGNORE_STARTUP_CFG\s*=\s*1') {throw 'ROMMON still indicates ignore-startup-config=1; manual correction required.'}
  }
  $script:success=$true
  Log 'SUCCESS: credential commands accepted, configuration saved, basic verification passed.'
} catch {
  Log $_.Exception.Message 'ERROR'
  Log 'RECOVERY INCOMPLETE. Check console output. Do not power-cycle until boot configuration is reviewed.' 'WARN'
} finally {
  if($null -ne $script:serial) {try {$script:serial.Close();$script:serial.Dispose()}catch{}}
  Log "Result: $(if($script:success){'SUCCESS'}else{'FAILED / INCOMPLETE'}); device=$($script:device); loader=$($script:family); elapsed=$([math]::Round(((Get-Date)-$script:started).TotalSeconds)) seconds"
  Log "Log file: $($script:log)"
  Write-Host "`nReport: $($script:log)" -ForegroundColor Cyan
  Write-Host "Status: $(if($script:success){'SUCCESS'}else{'FAILED / INCOMPLETE'})"
}
