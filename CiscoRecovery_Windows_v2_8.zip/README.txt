Cisco Console Recovery v2.8

Changes from v2.7:
- Detect -- MORE -- even across multiple serial chunks.
- Send precisely one SPACE per newly received pagination marker.
- Continue waiting for the returned switch: prompt.
- Keep existing legacy Catalyst, ISR/ASR and Catalyst 9000 logic unchanged.

Run Run-CiscoRecovery.cmd as before. Test on lab equipment before production use.
